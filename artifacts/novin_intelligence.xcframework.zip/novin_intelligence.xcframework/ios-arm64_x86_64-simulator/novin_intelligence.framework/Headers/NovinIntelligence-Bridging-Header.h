// NovinIntelligence-Bridging-Header.h
// Exposes the CPython C-API to Swift

#ifndef NovinIntelligence_Bridging_Header_h
#define NovinIntelligence_Bridging_Header_h

#include <Python.h>

#endif /* NovinIntelligence_Bridging_Header_h */

